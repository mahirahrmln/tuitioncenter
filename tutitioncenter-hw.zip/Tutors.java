public class Tutors {
    String name;
    int ic;
    String address;
    String qualification;
    int numYearsExp;
    int dateJoined;
    int numYearsInCenter;

    public Tutors (String name, int ic, String address, String qualification,int dateJoined, int numYearsExp, int numYearsInCenter) {
        this.name = name;
        this.ic = ic;
        this.address = address;
        this.qualification = qualification;
        this.numYearsExp = numYearsExp;
        this.dateJoined = dateJoined;
        this.numYearsInCenter = numYearsInCenter;
    }
}