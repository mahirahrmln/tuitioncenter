
class StudBatch{
    Student studentbatch[] = new Student[10];
    static int currstudent=0;
    String batchName;
    
    void addStudents(Student m){
        studentbatch[currstudent++]= m;
    }
    
    static int getcurrSt(){
        return currstudent;
    }
}