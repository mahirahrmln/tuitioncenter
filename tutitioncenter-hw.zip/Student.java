import java.util.Scanner;

public class Student {
    
    Scanner m = new Scanner(System.in);
    
    String name;
    int ic;
    String address;
    int year;
    String schoolName;
    double[] scores = new double[3];
    

    public Student(String name, int ic, String address, int year, String schoolName) {
        this.name = name;
        this.ic = ic;
        this.address = address;
        this.year = year;
        this.schoolName = schoolName;
    }
    
    public double[] getScores() {
        System.out.println("Enter marks:");
        for (int i = 0; i < 3; i++) {
            System.out.print("Subject " + (i + 1) + ": ");
            scores[i] = m.nextDouble();
        }
        return scores;
    }
    
    public double getMaxScore() {
        double maxScore = scores[0];
        for (int i = 1; i < scores.length; i++) {
            if (scores[i] > maxScore) {
                maxScore = scores[i];
            }
        }
        return maxScore;
    }

    public double getMinScore() {
        double minScore = scores[0];
        for (int i = 1; i < scores.length; i++) {
            if (scores[i] < minScore) {
                minScore = scores[i];
            }
        }
        return minScore;
    }

    public double getAvgScore() {
        if (scores.length > 0) {
            double totalScore = 0;
            for (double score : scores) {
                totalScore += score;
            }
            return (double) totalScore / scores.length;
        } else {
            return 0;
        }
    }
    
   

}
