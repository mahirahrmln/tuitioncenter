public class Tuition {
    String name;
    String address;
    String nHeadmaster;
    StudBatch listbatch[] = new StudBatch[5];
    static int currbatch=0;

    public Tuition(String name, String address, String nHeadmaster) {
        this.name = name;
        this.address = address;
        this.nHeadmaster = nHeadmaster;
    }
    
    void addBatch(StudBatch m){
        listbatch[currbatch++] = m;
    }
    
     static int getcurrbatch(){
        return currbatch;
    }

}
