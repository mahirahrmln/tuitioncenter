import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner scanner = new Scanner (System.in);

    //creating stud info
    Student Nana =
      new Student ("Nana", 1234, "Taman Cempaka,kl", 3, "Sk Seri Saujana");

    Student Munir =
      new Student ("Munir", 1256, "Taman Muhibbah,kl", 3, "Sk Seri Saujana");

    Student Aina =
      new Student ("Aina", 1278, "Taman Cempaka,Johor", 3,
		   "Sk Seri Petaling");

    //creating tutor info
    Tutors Tira =
      new Tutors ("Tira", 256, "Taman rainbow,Jalan Krian,Johor", "degree",
		  1 / 2 / 23, 2, 0);

    Tutors Zira =
      new Tutors ("Zira", 387, "Taman Sementa,Jaya", "degree", 3 / 2 / 23, 1,
		  1);

    Tutors Irham =
      new Tutors ("Irham", 298, "Kuala Selangor,Selangor", "spm", 9 / 10 / 21,
		  3, 3);

    //creating batch as Object

    StudBatch SB = new StudBatch ();
      SB.batchName = "Batch FEB";
      SB.addStudents (Nana);
      SB.addStudents (Munir);

    StudBatch SB1 = new StudBatch ();
      SB1.batchName = "Batch JUL";
      SB1.addStudents (Aina);

    // Creating tuition info
    Tuition johor =
      new Tuition ("Tuition Indah Sdn. Bhd.", "Taman Cempaka, Johor",
		   "Mustafa Kamal");
      johor.addBatch (SB);
      johor.addBatch (SB1);
      System.out.println ("Current number of students: " +
			  StudBatch.getcurrSt ());

    Tuition kl =
      new Tuition ("Tuition Meranti Sdn. Bhd.", "the Glorie, Kl",
		   "Saiful Mutalib");
      kl.addBatch (SB);
      kl.addBatch (SB1);
      System.out.println ("Current number of students: " +
			  StudBatch.getcurrSt ());

    ListTuition list = new ListTuition ();
      list.addTuition (johor);
      list.addTuition (kl);
      list.deleteTuition (johor);



    // output the report for the tuition  
      System.out.println ("Report for the Pandai Sdn. Bhd. Tuition center ");

      System.out.println ("Which state you looking forward (Johor/KL): ");
    String name = scanner.nextLine ();
    System.out.println(Nana.getScores());
     System.out.println("Average score: " + Nana.getAvgScore());
    System.out.println("Minimum score: " +  Nana.getMinScore());
    System.out.println("Maximum score: " + Nana.getMaxScore());



      scanner.close ();

  }
}
