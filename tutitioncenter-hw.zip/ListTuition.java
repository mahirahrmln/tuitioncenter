class ListTuition{
    Tuition ListTuition[] = new Tuition[10];
    int currsz =0;
    
    void addTuition(Tuition m){
        ListTuition[currsz ++] = m;
    }
    
    void deleteTuition(Tuition m){
        for (int i=0; i<currsz; i++){
            if (ListTuition[i] == m){
                ListTuition[i] = null;
                System.out.println("deleted");
            }
        }
        
    }
    
}